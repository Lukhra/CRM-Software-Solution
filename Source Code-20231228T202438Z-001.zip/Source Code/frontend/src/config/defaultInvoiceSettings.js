export default {
  companyName: '',
  gstNumber: '',
  taxPercent: 18,
  taxEnable: 'true',
  billableType: 'product',
  taxType: 'exc',
  companyAddress: '',
  note: 'Thank You For Shopping',
  currency: 'inr',
  currentErpNum: '0001',
};
