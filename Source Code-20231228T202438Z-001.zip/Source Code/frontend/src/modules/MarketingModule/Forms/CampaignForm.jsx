import React, { useState, useEffect, useRef } from 'react';
import { Form, Input, Button, Select, Divider, Row, Col } from 'antd';

import AutoCompleteAsync from '@/components/AutoCompleteAsync';

const { TextArea } = Input;

export default function CampaignForm({}) {
  const [campaignType, setCampaignType] = useState('News Letter');

  const defaultPromotionalMessage = `Our CRM tool provides a holistic view of customer interactions and history, allowing your team to understand and engage with clients more effectively. Make informed, data-driven decisions with our powerful analytics and reporting tools. Gain valuable insights that will drive your business strategy forward. Experience a seamless transition with our intuitive design. The user-friendly interface ensures that your team can quickly adopt and harness the power of the CRM tool. Connect effortlessly with other business applications, creating a unified workflow. Our CRM tool becomes the central hub for all your business operations, promoting collaboration and efficiency.`;

  return (
    <>
      <Row gutter={[12, 0]}>
        <Col className="gutter-row" span={12}>
          <Form.Item
            name="campaignName"
            label="Campaign Name"
            rules={[
              {
                required: true,
                message: 'Please input your campaign name!',
              },
            ]}
          >
            <Input />
          </Form.Item>
        </Col>
        <Col className="gutter-row" span={12}>
          <Form.Item
            name="campaignType"
            label="Campaign Type"
            rules={[
              {
                required: true,
                message: 'Please input campaign type!',
              },
            ]}
            initialValue={campaignType}
          >
            <Select
              onChange={(value) => {
                setCampaignType(value);
              }}
              options={[
                { value: 'News Letter', label: 'News Letter' },
                { value: 'Promotions', label: 'Seasonal Promotions' },
                { value: 'Survey and Feedback', label: 'Survey and Feedback' },
                { value: 'Referral', label: 'Referral Program' },
              ]}
            ></Select>
          </Form.Item>
        </Col>
        {campaignType !== 'News Letter' &&
        campaignType !== 'Survey and Feedback' &&
        campaignType !== 'Referral' ? (
          <Col className="gutter-row" span={24}>
            <Form.Item
              name="campaignDescription"
              label="Campaign Description"
              rules={[
                {
                  required: true,
                  message: 'Please input your campaign description!',
                },
              ]}
              initialValue={campaignType === 'Promotions' ? defaultPromotionalMessage : ''}
            >
              <TextArea rows={4} />
            </Form.Item>
          </Col>
        ) : null}
        <Col className="gutter-row" span={12}>
          <Form.Item
            name="clientSelected"
            label="Select Client"
            rules={[
              {
                required: true,
                message: 'Please input your client!',
              },
            ]}
          >
            <AutoCompleteAsync
              entity={'client'}
              displayLabels={['company']}
              searchFields={'company'}
            />
          </Form.Item>
        </Col>
        <Col className="gutter-row" span={12}>
          <Form.Item label="Additional Info" name="info">
            <Input />
          </Form.Item>
        </Col>
      </Row>
      <Divider dashed />
    </>
  );
}
