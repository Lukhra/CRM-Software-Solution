import React, { useEffect, useState } from 'react';

import { useDispatch, useSelector } from 'react-redux';

import { Button, Form, Row, Col } from 'antd';
import { SaveOutlined, PlusOutlined } from '@ant-design/icons';

import Loading from '@/components/Loading';
import { crud } from '@/redux/crud/actions';
import { useCrudContext } from '@/context/crud';
import { selectCreatedItem } from '@/redux/crud/selectors';

export default function CreateForm({
  config,
  formElements,
  withUpload = false,
  withSubmit = true,
}) {
  let { entity } = config;
  const dispatch = useDispatch();
  const { isLoading, isSuccess } = useSelector(selectCreatedItem);
  const { crudContextAction } = useCrudContext();
  const { panel, collapsedBox, readBox } = crudContextAction;
  const [form] = Form.useForm();

  const [buttonPressed, setButtonPressed] = useState('submitted');

  const onSubmit = (fieldsValue) => {
    console.log('FieldsValue', fieldsValue);
    console.log('buttonPressed', buttonPressed);

    if (fieldsValue.file && withUpload) {
      // Manually trim values before submission

      fieldsValue.file = fieldsValue.file[0].originFileObj;
    }

    const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
      acc[key] = typeof fieldsValue[key] === 'string' ? fieldsValue[key].trim() : fieldsValue[key];
      return acc;
    }, {});

    if (buttonPressed === 'Saved') {
      dispatch(
        crud.create({ entity, jsonData: { ...trimmedValues, status: buttonPressed }, withUpload })
      );
    } else if (buttonPressed === 'Initiated') {
      dispatch(
        crud.create({ entity, jsonData: { ...trimmedValues, status: buttonPressed }, withUpload })
      );
      dispatch(crud.mail({ entity, jsonData: trimmedValues }));
    } else {
      dispatch(crud.create({ entity, jsonData: trimmedValues, withUpload }));
    }
  };

  useEffect(() => {
    if (isSuccess) {
      readBox.open();
      collapsedBox.open();
      panel.open();
      form.resetFields();
      dispatch(crud.resetAction({ actionType: 'create' }));
      dispatch(crud.list({ entity }));
    }
  }, [isSuccess]);

  return (
    <Loading isLoading={isLoading}>
      <Form form={form} layout="vertical" onFinish={onSubmit}>
        {formElements}
        {withSubmit ? (
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        ) : (
          <Row gutter={[12, 0]}>
            <Col className="gutter-row" span={12}>
              <Form.Item>
                <Button
                  type="text-color"
                  htmlType="submit"
                  icon={<SaveOutlined />}
                  block
                  onClick={() => setButtonPressed('Saved')}
                >
                  Save
                </Button>
              </Form.Item>
            </Col>
            <Col className="gutter-row" span={12}>
              <Form.Item>
                <Button
                  type="primary"
                  htmlType="submit"
                  icon={<PlusOutlined />}
                  block
                  onClick={() => setButtonPressed('Initiated')}
                >
                  Initiate
                </Button>
              </Form.Item>
            </Col>
          </Row>
        )}
      </Form>
    </Loading>
  );
}
