const entity = 'marketing';

const Labels = {
  PANEL_TITLE: 'Marketing Campaigns',
  dataTableTitle: 'Campaigns Lists',
  ADD_NEW_ENTITY: 'Add New Campaign',
  DATATABLE_TITLE: 'Campaigns List',
  ENTITY_NAME: 'Campaign',
  CREATE_ENTITY: 'Initiate Campaign',
  UPDATE_ENTITY: 'Update Campaign',
};

const configPage = {
  entity,
  ...Labels,
};

export default configPage;
