import dayjs from 'dayjs';
import { Tag } from 'antd';
import React from 'react';

import CrudModule from '@/modules/CrudModule';
import CampaignForm from '@/modules/MarketingModule/Forms/CampaignForm';

import configPage from './config';

export default function Marketing() {
  const searchConfig = {
    displayLabels: ['campaignName', 'campaignType'],
    searchFields: 'campaignName,campaignType',
    outputValue: '_id',
  };
  const entityDisplayLabels = ['number', 'company'];

  const readColumns = [
    {
      title: 'Campaign Name',
      dataIndex: 'campaignName',
    },
    {
      title: 'Campaign Type',
      dataIndex: 'campaignType',
    },
    {
      title: 'Campaign Description',
      dataIndex: 'campaignDescription',
    },
    {
      title: 'Client Selected',
      dataIndex: 'clientSelected.company',
    },
    {
      title: 'Additional Info',
      dataIndex: 'additionalInfo',
    },
    {
      title: 'Status',
      dataIndex: 'status',
    },
  ];

  const dataTableColumns = [
    {
      title: 'Campaign Name',
      dataIndex: ['campaignName'],
    },
    {
      title: 'Campaign Type',
      dataIndex: ['campaignType'],
    },
    {
      title: 'Client Selected',
      dataIndex: ['clientSelected', 'company'],
    },
    {
      title: 'Status',
      dataIndex: 'status',
      render: (status) => {
        let color = status === 'Saved' ? 'cyan' : status === 'Initiated' ? 'green' : 'red';
        return <Tag color={color}>{status && status.toUpperCase()}</Tag>;
      },
    },
    {
      title: 'Created At',
      dataIndex: 'created',
      render: (date) => dayjs(date).format('DD/MM/YYYY'),
    },
  ];

  const config = {
    ...configPage,
    readColumns,
    dataTableColumns,
    searchConfig,
    entityDisplayLabels,
  };
  return (
    <CrudModule
      createForm={<CampaignForm />}
      updateForm={<CampaignForm isUpdateForm={true} />}
      config={config}
      withSubmit={false}
    />
  );
}
