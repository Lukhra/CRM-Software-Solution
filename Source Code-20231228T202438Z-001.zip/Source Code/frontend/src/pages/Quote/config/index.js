const entity = 'quote';

const Labels = {
  PANEL_TITLE: 'Quote',
  dataTableTitle: 'Quotes Lists',
  ADD_NEW_ENTITY: 'Add new quote',
  DATATABLE_TITLE: 'Quotes List',
  ENTITY_NAME: 'Quote',
  CREATE_ENTITY: 'Save quote',
  UPDATE_ENTITY: 'Update quote',
};

const configPage = {
  entity,
  ...Labels,
};

export default configPage;
