const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

const marketingSchema = new mongoose.Schema({
  removed: {
    type: Boolean,
    default: false,
  },
  campaignName: {
    type: String,
    default: false,
    required: true,
  },
  campaignType: {
    type: String,
    default: false,
    enum: ['News Letter', 'Promotions', 'Survey and Feedback', 'Referral'],
  },
  campaignDescription: {
    type: String,
    required: false,
  },
  clientSelected: {
    type: mongoose.Schema.ObjectId,
    ref: 'Client',
    required: true,
    autopopulate: true,
  },
  additionalInfo: {
    type: String,
    required: false,
  },
  status: {
    type: String,
    default: 'draft',
  },
  updated: {
    type: Date,
    default: Date.now,
  },
  created: {
    type: Date,
    default: Date.now,
  },
});

marketingSchema.plugin(require('mongoose-autopopulate'));
module.exports = mongoose.model('Marketing', marketingSchema);
