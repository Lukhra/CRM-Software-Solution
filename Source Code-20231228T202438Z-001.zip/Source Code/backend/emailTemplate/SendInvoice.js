exports.SendInvoice = ({ title = 'Invoice from Idurar', name = '', time = new Date() }) => {
  return `
    <div>

        <head data-id="__react-email-head">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <title>${title}</title>
        </head>
        <div id="__react-email-preview" style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0">Your invoice - Idurar<div> ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿</div>
        </div>

        <body data-id="__react-email-body">
            <h2 data-id="react-email-heading">${title}</h2>
            <hr data-id="react-email-hr" style="width:100%;border:none;border-top:1px solid #eaeaea" />
            <p data-id="react-email-text" style="font-size:14px;line-height:24px;margin:16px 0">Hello ${name},</p>
            <p data-id="react-email-text" style="font-size:14px;line-height:24px;margin:16px 0">Here&#x27;s the invoice you requested at ${time}</p>
        </body>
    </div>
    `;
};

exports.SendQuote = ({ title = 'Quote from Idurar', name = '', time = new Date() }) => {
  return `
    <div>
        <head data-id="__react-email-head">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <title>${title}</title>
        </head>
        <div id="__react-email-preview" style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0">Your quote - Idurar<div> ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿ ‌​‍‎‏﻿</div>
        </div>

        <body data-id="__react-email-body">
            <h2 data-id="react-email-heading">${title}</h2>
            <hr data-id="react-email-hr" style="width:100%;border:none;border-top:1px solid #eaeaea" />
            <p data-id="react-email-text" style="font-size:14px;line-height:24px;margin:16px 0">Hello ${name},</p>
            <p data-id="react-email-text" style="font-size:14px;line-height:24px;margin:16px 0">Here&#x27;s the quote you requested at ${time}</p>
        </body>
    </div>
    `;
};

exports.SendNewsLetter = `
    <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Your Enterprise CRM Newsletter</title>
                <style>
                    body {
                        font-family: 'Arial', sans-serif;
                        margin: 0;
                        padding: 0;
                        background-color: #f4f4f4;
                    }

                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        background-color: #ffffff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    }

                    h1 {
                        color: #333;
                    }

                    p {
                        color: #666;
                        margin-bottom: 15px;
                    }

                    .cta-button {
                        display: inline-block;
                        margin-top: 15px;
                        padding: 10px 20px;
                        background-color: #4CAF50;
                        color: #fff;
                        text-decoration: none;
                        border-radius: 5px;
                    }

                    .image-container {
                        text-align: center;
                        margin-top: 20px;
                    }

                    img {
                        max-width: 100%;
                        height: auto;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Your Enterprise CRM Tool Newsletter</h1>
                    <p>Dear #NAME#,</p>

                    <p>We are thrilled to share the latest enhancements and features of our Enterprise CRM tool designed to empower your business in managing customer relationships more efficiently.</p>

                    <p>Our CRM tool is more than just a database; it's a comprehensive solution that enables your team to have a 360-degree view of customer interactions. Seamlessly manage customer data, track communication, and enhance collaboration among team members.</p>

                    <p>One of the standout features is our advanced analytics and reporting capabilities. Dive deep into your data to uncover valuable insights, trends, and patterns. Make data-driven decisions that propel your business forward and stay ahead of the competition.</p>

                    <p>The intuitive user interface ensures that your team can harness the power of the CRM tool without the need for extensive training. It's user-friendly, customizable, and adaptable to your specific business needs, ensuring a smooth and efficient workflow.</p>

                    <p>But that's not all! Our tool goes beyond traditional CRM functionalities. It integrates seamlessly with other business applications, providing a unified platform for your team to work collaboratively. Whether it's marketing, sales, or customer support, our CRM tool is the central hub for all your business operations.</p>

                    <p></p>
                    
                    <a href="https://www.idurarapp.com/" class="cta-button">Explore Now</a>

                    <p></p>

                    <p>Thank you for choosing IDURAR as your CRM solution provider. If you have any questions or need assistance, feel free to contact our support team.</p>

                    <p>Best regards,<br>
                    IDURAR Team</p>
                </div>
            </body>
        </html>
`;

exports.SendPromotions = `
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Enterprise CRM Tool Awaits</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }

            .container {
                max-width: 600px;
                margin: 0 auto;
                background-color: #ffffff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            h1 {
                color: #333;
            }

            p {
                color: #666;
                margin-bottom: 15px;
            }

            .cta-button {
                display: inline-block;
                margin-top: 15px;
                padding: 10px 20px;
                background-color: #4CAF50;
                color: #fff;
                text-decoration: none;
                border-radius: 5px;
            }

            .image-container {
                text-align: center;
                margin-top: 20px;
            }

            img {
                max-width: 100%;
                height: auto;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Supercharge Your Business with Our Enterprise CRM Tool!</h1>
            <p>Dear #NAME#,</p>

            <p>We're excited to introduce our cutting-edge Enterprise CRM tool designed to elevate your business operations 
            and supercharge your customer relationships. Say goodbye to tedious manual processes and hello to efficiency!</p>

            <p>#CAMPAIGN_DESCRIPTION#</p>

            <p>Ready to take the leap? Click below to explore how our CRM tool can transform your business:</p>

            <a href="https://www.idurarapp.com/" class="cta-button">Explore Now</a>

            <p>Still not convinced? Schedule a personalized demo with our experts to experience the tool in action. 
            We're here to answer any questions you may have!</p>

            <p>Thank you for considering IDURAR as your CRM solution. We look forward to helping you drive success 
            and build lasting customer relationships.</p>

            <p>Best regards,<br>
            IDURAR Team</p>
        </div>
    </body>
</html>
`;

exports.SendSurveyAndFeedBack = `
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>We Value Your Feedback on Our CRM Tool</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }

            .container {
                max-width: 600px;
                margin: 0 auto;
                background-color: #ffffff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            h1 {
                color: #333;
            }

            p {
                color: #666;
                margin-bottom: 15px;
            }

            .cta-button {
                display: inline-block;
                margin-top: 15px;
                padding: 10px 20px;
                background-color: #4CAF50;
                color: #fff;
                text-decoration: none;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>We Want to Hear From You!</h1>
            <p>Dear #NAME#,</p>

            <p>We hope you are enjoying the benefits of our Enterprise CRM tool and that it is making a positive impact on your business operations. At IDURAR, we are committed to continuous improvement, and your feedback is invaluable to us.</p>

            <p>We would greatly appreciate it if you could take a few minutes to complete our survey. Your insights will help us understand how well the CRM tool is meeting your needs and where we can make enhancements for an even better user experience.</p>

            <p><strong>Your Feedback Matters:</strong></p>
            <ul>
                <li>How satisfied are you with the features of our CRM tool?</li>
                <li>What specific functionalities do you find most valuable?</li>
                <li>Are there any areas where you think we can improve?</li>
            </ul>

            <p>To participate in the survey, click the button below:</p>
            <a href="https://your-survey-link.com" class="cta-button">Take the Survey</a>

            <p>We genuinely value your opinion, and your feedback will directly influence the future development of our CRM tool. Thank you for being a part of our journey towards excellence.</p>

            <p>If you have any immediate concerns or would like to share additional thoughts, please feel free to reply to this email.</p>

            <p>Thank you for choosing IDURAR as your CRM solution provider.</p>

            <p>Best regards,<br>
            IDURAR Team</p>
        </div>
    </body>
</html>
`;

exports.SendReferral = `
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Your Referral Can Make a Difference</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }

            .container {
                max-width: 600px;
                margin: 0 auto;
                background-color: #ffffff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            h1 {
                color: #333;
            }

            p {
                color: #666;
                margin-bottom: 15px;
            }

            .cta-button {
                display: inline-block;
                margin-top: 15px;
                padding: 10px 20px;
                background-color: #4CAF50;
                color: #fff;
                text-decoration: none;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Your Referral Can Make a Difference!</h1>
            <p>Dear #NAME#,</p>

            <p>We hope this email finds you well. At IDURAR, we greatly value the relationships we've built with our clients, and we're reaching out to you because we believe your network could benefit from our Enterprise CRM tool, just as you have.</p>

            <p>If you've found our CRM tool to be a valuable asset in streamlining your business operations, we would be honored if you could refer us to other businesses or colleagues who might also benefit from our solution.</p>

            <p>Our Enterprise CRM tool offers comprehensive customer relationship management, advanced analytics for data-driven decision-making, a user-friendly interface for seamless adoption, and seamless integration with other business applications.</p> 
            <p></p>
            <p>Help others experience the same benefits you've enjoyed by clicking the button below to refer IDURAR and our Enterprise CRM tool:</p>
            <a href="https://your-referral-link.com" class="cta-button">Refer Now</a>

            <p>We appreciate your support, and as a token of our gratitude, for every successful referral, you and the referred business will receive a special discount on our services.</p>

            <p>Thank you for considering referring IDURAR. If you have any questions or need further information, feel free to reply to this email.</p>

            <p>Best regards,<br>
            IDURAR Team</p>
        </div>
    </body>
</html>
`;
