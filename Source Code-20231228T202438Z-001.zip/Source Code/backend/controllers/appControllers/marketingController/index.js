const createCRUDController = require('@/controllers/middlewaresControllers/createCRUDController');
const methods = createCRUDController('Marketing');

const sendMail = require('./mailMarketingController');
const downloadExcel = require('./excelMarketingController');

methods.sendMail = sendMail;
methods.downloadExcel = downloadExcel;

module.exports = methods;
