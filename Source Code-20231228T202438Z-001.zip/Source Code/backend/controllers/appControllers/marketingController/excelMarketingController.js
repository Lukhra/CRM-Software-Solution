const excel = require('excel4node');
const workbook = new excel.Workbook();
const mongoose = require('mongoose');
const CampaignModel = mongoose.model('Marketing');

const boldFont = {
  font: {
    bold: true,
    color: '000000',
  },
};

async function transformCampaignData(campaignData) {
  const finalData = [];
  try {
    for (let i = 0; i < campaignData.length; i++) {
      let singleElement = campaignData[i];
      let createdDate = new Date(singleElement.created);
      let temp = {
        'Campaign Name': singleElement.campaignName,
        'Campaign Type': singleElement.campaignType,
        'Client Selected': singleElement.clientSelected.company,
        Created:
          createdDate.getMonth() +
          1 +
          '-' +
          createdDate.getDate() +
          '-' +
          createdDate.getFullYear(),
      };
      finalData.push(temp);
    }
  } catch (error) {
    console.log('Error : ', error);
  }
  return finalData;
}

async function getCampaignData() {
  return new Promise(async (resolve, reject) => {
    const campaignData = await CampaignModel.find({ removed: false })
      .sort({ created: -1 })
      .populate();
    const finalData = transformCampaignData(campaignData);

    resolve(finalData);
  });
}

async function generateCampaignExcel(excel_data) {
  new Promise(async (resolve, reject) => {
    try {
      console.log('In Generate Campaign Excel');

      const campaignExcel = workbook.addWorksheet('Campaign Data');
      processCampaignData(excel_data, campaignExcel, workbook);

      resolve();
    } catch (err) {
      reject(err);
    }
  });
}

function processCampaignData(excel_data, campaignExcel, workbook) {
  console.log('In ProcessCampaignData');

  let myStyle = workbook.createStyle(boldFont);

  let feilds = ['Campaign Name', 'Campaign Type', 'Client Selected', 'Created'];
  feilds.forEach((item, index, arr) => {
    campaignExcel
      .cell(1, 1 + index)
      .string(item)
      .style(myStyle);
  });

  if (
    excel_data.campaignData &&
    Array.isArray(excel_data.campaignData) &&
    excel_data.campaignData.length > 0
  ) {
    for (let k = 0; k < excel_data.campaignData.length; k++) {
      let sec = excel_data.campaignData[k];

      campaignExcel
        .cell(2 + k, 1)
        .string(k + '')
        .style(myStyle);
      feilds.forEach((item, index) => {
        campaignExcel.cell(2 + k, 1 + index).string(sec[item] + '');
      });
    }
  }
}

module.exports = downloadExcel = async (req, res) => {
  try {
    console.log('In Download Excel');
    const campaignData = await getCampaignData();
    let excel_data = {};
    excel_data.campaignData = campaignData;

    await generateCampaignExcel(excel_data);
    return workbook.write(`Campaign Data ${new Date().getTime()}.xlsx`, res);
  } catch (error) {
    console.log('Reached Here');
    // If error is thrown by Mongoose due to required validations
    if (error.name == 'ValidationError') {
      return res.status(400).json({
        success: false,
        result: null,
        error: error,
        message: 'Required fields are not supplied',
      });
    } else if (error.name == 'BSONTypeError') {
      // If error is thrown by Mongoose due to invalid ID
      return res.status(400).json({
        success: false,
        result: null,
        error: error,
        message: 'Invalid ID',
      });
    } else {
      // Server Error
      return res.status(500).json({
        success: false,
        result: null,
        error: error,
        message: error.message,
      });
    }
  }
};
