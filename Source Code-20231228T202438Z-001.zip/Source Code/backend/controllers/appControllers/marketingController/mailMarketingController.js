const {
  SendNewsLetter,
  SendPromotions,
  SendSurveyAndFeedBack,
  SendReferral,
} = require('@/emailTemplate/SendInvoice');
const mongoose = require('mongoose');
const ClientModel = mongoose.model('Client');

const sgMail = require('@sendgrid/mail');
sgMail.setApiKey('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');

module.exports = sendMail = async (req, res) => {
  try {
    console.log('Request', req.body);

    const { clientSelected: client, campaignType, campaignDescription = '' } = req.body;
    const { email, managerName } = await ClientModel.findById(client).exec();

    let HTML;
    if (campaignType === 'News Letter') {
      HTML = SendNewsLetter;
      HTML = HTML.replace('#NAME#', managerName);
    } else if (campaignType === 'Promotions') {
      HTML = SendPromotions;
      HTML = HTML.replace('#NAME#', managerName);
      HTML = HTML.replace('#CAMPAIGN_DESCRIPTION#', campaignDescription);
    } else if (campaignType === 'Survey and Feedback') {
      HTML = SendSurveyAndFeedBack;
      HTML = HTML.replace('#NAME#', managerName);
    } else if (campaignType === 'Referral') {
      HTML = SendReferral;
      HTML = HTML.replace('#NAME#', managerName);
    }

    const msg = {
      to: email,
      from: 'himanshusinghal178@gmail.com',
      subject: 'IDURAR News Letter',
      html: HTML,
    };

    sgMail
      .send(msg)
      .then((response) => {
        return res.status(200).json({
          success: true,
          result: email,
          message: `Successfully sent mail to ${email}`,
        });
      })
      .catch((error) => {
        return res.status(500).json({
          success: false,
          result: null,
          error: error,
          message: error.message,
        });
      });
  } catch (error) {
    // If error is thrown by Mongoose due to required validations
    if (error.name == 'ValidationError') {
      return res.status(400).json({
        success: false,
        result: null,
        error: error,
        message: 'Required fields are not supplied',
      });
    } else if (error.name == 'BSONTypeError') {
      // If error is thrown by Mongoose due to invalid ID
      return res.status(400).json({
        success: false,
        result: null,
        error: error,
        message: 'Invalid ID',
      });
    } else {
      // Server Error
      return res.status(500).json({
        success: false,
        result: null,
        error: error,
        message: error.message,
      });
    }
  }
};
